package de.averbis;

import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.fit.component.JCasAnnotator_ImplBase;
import org.apache.uima.jcas.JCas;

import de.averbis.types.Testannotation;

/**
 * @author entwicklerteam
 */
public class AnnotatorTwo extends JCasAnnotator_ImplBase {

	@Override
	public void process(JCas jCas) throws AnalysisEngineProcessException {

		System.out.println("Processing AnnotatorTwo....");
		Testannotation testannotation = new Testannotation(jCas, 0, jCas.getDocumentText().length());
		testannotation.setTestfeature("test");
		testannotation.addToIndexes();
	}
}