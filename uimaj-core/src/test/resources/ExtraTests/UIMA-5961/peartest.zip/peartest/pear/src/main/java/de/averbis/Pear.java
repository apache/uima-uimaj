package de.averbis;

import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.fit.component.JCasAnnotator_ImplBase;
import org.apache.uima.jcas.JCas;

public class Pear extends JCasAnnotator_ImplBase {

	public static final String MESSAGE_BUNDLE = "de.averbis.pear";


	@Override
	public void process(JCas jcas) throws AnalysisEngineProcessException {

		Object[] objects = new Object[] { "ARGUMENT" };
		throw new AnalysisEngineProcessException(MESSAGE_BUNDLE, "PROCESS_KEY", objects);
	}
}