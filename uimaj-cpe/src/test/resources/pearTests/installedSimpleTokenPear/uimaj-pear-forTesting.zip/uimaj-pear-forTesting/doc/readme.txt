
   ***************************************************************
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
         *
   *   http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   ***************************************************************
   
This directory is the source for an Eclipse project called uimaj-pear-forTesting.  It's only purpose
is to construct a pear that can be used in testing.  The pear it constructs does nothing except 
instantiate a JCas Sentence annotator.  (Other actions could be added as needed).

The resulting pear is already "installed" in the uimaj-cpe project, which uses it for testing running of
PEARs in multiple pipelines.

This is only here in case the source is needed for fixing, changing, etc.  To do that, put the parent directory
in an eclipse workspace, and import it as a new project.  The .project files include the UIMA Nature, so when
you're done you can use the Pear wizard to package this.

Then you'll need to "install" it into the CPE src/test/resources in the right spot.  Also, you have to replace
all instances in the install of absolute paths, with relative paths.  That is, change:
c:\a\b\c\uimaj-cpe\src\test\... etc. to
                   src\test\...
                                      
